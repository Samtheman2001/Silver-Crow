"""Silver Crow modular package."""

