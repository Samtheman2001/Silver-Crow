import html
import random
from copy import deepcopy

import streamlit as st

st.set_page_config(
    page_title="Silver Crow",
    page_icon="🪶",
    layout="wide",
    initial_sidebar_state="collapsed",
)

from .config import (
    ACTION_OPTIONS,
    ATTRIBUTES,
    BACKGROUNDS,
    BASE_STATE,
    CHARACTER_INITIATIVES,
    FOLLOW_UP_NODES,
    DEFAULT_SAY_OPTIONS,
    PERSONALITIES,
    PHYSICAL_STATES,
    SAY_OPTIONS,
    SCENARIOS,
    STARTING_MOODS,
    get_say_options_for_scenario,
)

from .utils import (
    _dna_clamp_trait,
    _stable_seed_from_text,
    apply_mods,
    apply_ripple_effects,
    build_state,
    clamp,
    clamp01,
    murdered_state,
    normalize_speech,
    quote,
    say_option_stat_mods,
    scale_stat_mods,
    strip_outer_quotes,
    verbal_triggers_conversation_shutdown,
)

from .memory import (
    derive_read_on_you,
    init_memory_state,
    memory_add_recent,
    normalize_user_text,
    propose_interaction_trajectory,
    relationship_trend,
    update_conversation_memory,
    update_interaction_trajectory,
)

from .personality import (
    apply_mods_with_identity,
    dna_scaled_mods,
    generate_personality_dna,
    get_character_dna,
    init_identity_state,
    maybe_apply_personal_quirk,
)

from .free_text import (
    CAT_MODE_FREE_TEXT_EFFECTS,
    FREE_TEXT_AGGRESSIVE_HARD_SUBSTR,
    FREE_TEXT_AGGRESSIVE_HARD_WORDS,
    FREE_TEXT_AGGRESSIVE_LIGHT_SUBSTR,
    FREE_TEXT_AGGRESSIVE_MEDIUM_SUBSTR,
    FREE_TEXT_AGGRESSIVE_MEDIUM_WORDS,
    FREE_TEXT_AWKWARD,
    FREE_TEXT_CATEGORY_EFFECTS,
    FREE_TEXT_FRIENDLY,
    FREE_TEXT_JOKING,
    _SPEECH_GREETING_FRAGMENTS,
    aggressive_comeback_response,
    free_text_hard_slur_guard,
    free_text_insult_is_baiting,
    free_text_verbal_response,
    free_text_weak_insult_phrase,
    greeting_or_checkin_overlap,
    interpret_free_text,
    scaled_free_text_category_mods,
    should_use_cat_mode,
    speech_echoes_recent,
)

from .responses import (
    fill_name_tokens,
    outcome_summary,
    relationship_label,
    relationship_status,
)

from .behavior_gate import (
    EMOTIONAL_PRESSURE,
    LAST_STALL_CHECK_KEY,
    SESSION_MODE_KEY,
    apply_question_type_stat_relief,
    filter_stall_from_pool_lines,
    record_last_response_for_stall_gate,
    resolve_response_mode,
)
from .emotional_subtype import (
    PRESSURE_DEFAULT,
    ROMANTIC_PRESSURE,
    VALIDATION_SEEKING,
    record_menu_emotional_turn,
    subtype_stat_overlay,
)
from .first_impression import calibrate_bucket_for_polite_opener, first_impression_verbal_locked
from .menu_responses import (
    filter_generic_engaged_fallback_pool,
    is_low_stakes_personal_prompt,
    maybe_menu_intelligent_response,
    register_emotional_menu_prompt,
    reset_menu_emotional_pressure,
    soften_low_stakes_menu_mods,
)
from .response_intent import RECENT_INTENTS_KEY

from .brain import (
    _brain_pick,
    _crow_brain_pick_variant,
    _crow_seed_from_state,
    _maybe_add_hesitation,
    _maybe_spike_moment,
    _micro_variation,
    _normalize_verbal_for_compare,
    _bump_linger_from_attitude,
    choose_bucket,
    crow_brain_apply_to_verbal,
    crow_brain_interpret,
    generate_crow_brain_state,
    infer_physical_response,
    infer_tone,
    infer_vibe,
    init_human_variation_state,
)

from .ui import app_css as ui_app_css, attribute_color, format_delta, get_avatar


def _scaled_menu_say_mods(choice: str, scale_factor: float = 0.42) -> dict:
    option = SAY_OPTIONS.get(choice)
    if option is None:
        return {}
    sm = dict(scale_stat_mods(say_option_stat_mods(option), scale_factor) or {})
    if sm and is_low_stakes_personal_prompt(choice):
        sm = soften_low_stakes_menu_mods(sm)
    sub = (st.session_state.get(SESSION_MODE_KEY) or {}).get("emotional_subtype", PRESSURE_DEFAULT)
    extra = subtype_stat_overlay(sub)
    for k, v in extra.items():
        if k in sm:
            sm[k] = sm[k] + int(round(v * scale_factor))
        elif v != 0:
            sm[k] = int(round(v * scale_factor))
    return sm


def build_response(
    action_text,
    kind,
    state,
    character_name,
    scenario_name,
    personality=None,
    free_text_category=None,
    turns_before_reply=0,
    starting_mood="Neutral",
):
    personality = personality or "Confident"
    if kind == "say" and free_text_category:
        return free_text_verbal_response(
            free_text_category, personality, state, character_name, raw_text=action_text
        )

    tone = infer_tone(state)
    physical = infer_physical_response(state)
    vibe = infer_vibe(state)

    if scenario_name == "Meeting Girlfriend's Parents" and action_text == "Will I ever live up to her ex boyfriend?":
        verbal = (
            'The mom goes quiet for a second and says, "No. His name was Sam Howell and he was a beast. I miss him..." '
            'Then the dad interjects: "It\'s okay honey. It\'s unfair to compare this busta to the G.O.A.T."'
        )
        return verbal, "hostile", "the room freezes and both parents stare with devastating sincerity", "emotionally catastrophic"

    if scenario_name == "Meeting Girlfriend's Parents" and state["anger"] > 72 and state["trust"] < 28:
        verbal = 'The dad leans forward and says, "You are a busta and I hate you."'
        return verbal, tone, physical, vibe

    if "Sam Howell" in action_text:
        verbal = "Sam Howell? That's a legendary reference."
        return quote(verbal), tone, physical, vibe

    if kind == "say":
        bucket = choose_bucket(state, personality)
        mem_fb = st.session_state.get("conversation_memory") or init_memory_state()
        bucket = calibrate_bucket_for_polite_opener(
            bucket,
            action_text,
            turns_before_reply,
            state,
            get_character_dna(),
            starting_mood,
            scenario_name,
            mem_fb,
        )

        menu_line = maybe_menu_intelligent_response(
            action_text,
            state,
            personality,
            character_name,
            bucket,
        )
        if menu_line:
            return quote(fill_name_tokens(menu_line)), tone, physical, vibe

        if action_text == "I disagree with you.":
            branch = {
                "positive": ["Okay—tell me why.", "You don't have to agree with me.", "Say your piece."],
                "neutral": ["Alright.", "Whatever.", "You don't have to believe me."],
                "negative": ["Then disagree.", "Okay, whatever.", "I'm not changing it for you."],
                "severe": ["Shut up, bitch.", "Then keep it moving.", "I heard you. I do not care."],
            }
            return quote(random.choice(branch[bucket])), tone, physical, vibe

        if action_text == "You're wrong.":
            branch = {
                "positive": ["Make your case.", "Okay, interesting. Tell me why.", "I'm listening."],
                "neutral": ["Convince me.", "Say it with reasons.", "Alright, say more."],
                "negative": ["No, you're just talking.", "You can think that.", "That doesn't make you right."],
                "severe": ["Watch your tone.", "You don't know what you're talking about.", "Say that again and this gets worse."],
            }
            return quote(random.choice(branch[bucket])), tone, physical, vibe

    # Personality-colored fallbacks: warmer, colder, or more analytical
    verbal_map = {
        "warm": [
            "I appreciate that.", "That actually lands.", "Okay—that's fair.",
            "Thanks.", "Yeah, that tracks.",
        ],
        "hostile": [
            "Watch your tone.", "Okay, whatever.", "I heard you.",
            "Try again.", "Say that again and see what happens.",
        ],
        "tense": [
            "This is getting uncomfortable.", "Be careful right now.",
            "I'm trying to stay calm.", "You're pushing it.",
            "I need a second.",
        ],
        "uncertain": [
            "I'm not sure what you mean.", "That came across a little strange.",
            "Give me a second.", "Wait, what?", "Run that by me again.",
        ],
        "engaged": [
            "Okay, now we're getting somewhere.", "That's actually interesting.",
            "You have my attention.", "Go on.", "Yeah?",
        ],
        "neutral": [
            "Alright.", "Okay.", "Yeah.", "Fine.", "Sure.", "Mhm.",
        ],
    }
    if personality == "Confident":
        verbal_map = {
            **verbal_map,
            "warm": ["I hear you.", "That tracks.", "Okay—say more.", "Noted. Keep going."],
            "neutral": ["Alright.", "Yeah.", "So?", "Fine.", "Go on."],
            "engaged": ["Be specific.", "What's your point?", "I'm listening—talk."],
            "tense": ["You're pushing it.", "Ease up.", "Watch how you say that.", "I don't like that angle."],
            "uncertain": ["Run that back.", "What do you mean?", "Say that again—clearly."],
        }
    # Personality tweaks for generic fallbacks
    personality_tweaks = {
        "Shy": {"warm": ["Oh. That's… nice.", "Thanks."], "neutral": ["Okay.", "I guess."]},
        "Aggressive": {"hostile": ["Watch it.", "Don't."], "tense": ["Back off."]},
        "Empathetic": {"warm": ["I really appreciate that.", "That's kind of you."]},
        "Analytical": {"engaged": ["Interesting—say more.", "Where are you going with that?"]},
        "Impulsive": {"hostile": ["What?", "Seriously?"], "engaged": ["Wait, yeah—", "Okay okay—"]},
    }
    mode_fb = st.session_state.get(SESSION_MODE_KEY) or {}
    pool = list(verbal_map.get(tone, verbal_map["neutral"]))
    if personality in personality_tweaks and tone in personality_tweaks[personality]:
        pool = pool + list(personality_tweaks[personality][tone])
    if kind == "say" and not free_text_category:
        pool = filter_generic_engaged_fallback_pool(
            pool,
            action_text,
            str(mode_fb.get("question_type", "")),
        )
    if mode_fb.get("allow_stall_language") is False or mode_fb.get("block_stall_language"):
        pool = filter_stall_from_pool_lines(pool)
    return quote(random.choice(pool)), tone, physical, vibe


def action_reaction(action_text, count, state, personality, before_state=None):
    tone = infer_tone(state)
    vibe = infer_vibe(state)
    physical = infer_physical_response(state)
    aggressive_end = personality in {"Aggressive", "Impulsive"}

    if action_text == "Smile":
        if count == 1:
            ref = before_state if before_state is not None else state
            upset_context = (
                ref["anger"] > 52
                or ref["trust"] < 38
                or (ref["stress"] > 62 and ref["anger"] > 40)
            )
            if upset_context:
                return quote(random.choice([
                    "Why are you smiling right now?",
                    "Is this funny to you?",
                    "What's funny?",
                    "I don't get why you're smiling.",
                ])), "tense", "stares at you without returning it", "uncomfortable", False
            return "", tone, "smiles back slightly", vibe, False
        if count == 2:
            return "", "uncertain", "tilts head a little like they're trying to read you", "mildly confused", False
        if count == 3:
            return quote("Why are you just smiling at me?"), "tense", "leans back slightly", "awkward", False
        if count == 4:
            return quote("Alright, you're being weird now. If you keep doing this I'm leaving."), "hostile", "stops smiling and looks annoyed", "vibe slipping", False
        if aggressive_end:
            return quote("What is your problem? Back up."), "hostile", "slaps your hand away and storms off", "murdered", True
        return quote("I'm leaving. This is too weird."), "hostile", "walks away shaking their head", "murdered", True

    if action_text == "Stare blankly":
        if count == 1:
            return quote("...You good?"), "uncertain", "waves a hand in front of your face", "awkward", False
        if count == 2:
            return quote("Okay, now you're doing a little too much."), "tense", "leans back and furrows brow", "awkward", False
        if count == 3:
            return quote("Why are you staring at me like that?"), "hostile", "breaks eye contact and looks irritated", "vibe slipping", False
        if count == 4:
            return quote("Stop that. Seriously."), "hostile", "looks openly unsettled now", "vibe slipping", False
        if aggressive_end:
            return quote("Back up before I make this a problem."), "hostile", "steps in and snaps at you", "murdered", True
        return quote("Nope. I'm out."), "hostile", "gets up and leaves", "murdered", True

    if action_text == "Step closer":
        if count == 1:
            return "", tone, physical, vibe, False
        if count == 2:
            return quote(random.choice([
                "Woah there.",
                "Hey—personal space.",
                "Okay, back up a little.",
            ])), "tense", "leans back and puts a hand up", "on edge", False
        if count == 3:
            return quote(random.choice([
                "I said back up.",
                "You need to give me some space.",
                "Seriously, step back.",
            ])), "hostile", "stiffens and takes a full step back", "uncomfortable", False
        if count >= 4:
            if aggressive_end:
                return quote("Touch me and we're done."), "hostile", "squares up", "murdered", True
            return quote("I'm leaving."), "hostile", "backs away and turns to go", "murdered", True

    if action_text == "Offer handshake":
        if count == 1:
            return "", tone, "takes the handshake after a short pause", vibe, False
        if count == 2:
            return quote("We already did that."), "uncertain", "looks at your hand, confused", "awkward", False
        if count == 3:
            return quote("Okay, enough with the hand thing."), "tense", "refuses the handshake", "annoyed", False
        if count == 4:
            return quote("Touch me again and this goes badly."), "hostile", "pulls away hard", "hostile", False
        if aggressive_end:
            return quote("Touch me again and we're going to have a problem."), "hostile", "pulls away hard and squares up", "murdered", True
        return quote("Nope. Conversation over."), "hostile", "steps back and ends the interaction", "murdered", True

    # Default for actions without specific handling (Step back, Look away, etc.)
    if count == 1:
        return "", tone, physical, vibe, False
    if count == 2:
        return quote("You just did that."), "uncertain", "looks a little confused", "awkward", False
    if count == 3:
        return quote("Why do you keep doing that?"), "tense", "fidgets and watches you more carefully", "vibe slipping", False
    if count == 4:
        return quote("If you keep doing that, I'm gone."), "hostile", "gets visibly annoyed", "vibe slipping", False
    if aggressive_end:
        return quote("Stop doing that."), "hostile", "snaps at you and shuts the interaction down", "murdered", True
    return quote("Okay, I'm done here."), "hostile", "pulls back and leaves", "murdered", True


def set_defaults():
    defaults = {
        "page": "builder",
        "character_built": False,
        "state": deepcopy(BASE_STATE),
        "history": [],
        "character_name": "Character",
        "selected_scenario": list(SCENARIOS.keys())[0],
        "turns": 0,
        "build_snapshot": {},
        "last_deltas": {k: 0 for k in ATTRIBUTES},
        "repeat_counts": {},
        "action_repeat_counts": {},
        "conversation_over": False,
        "ending_message": "",
        "draft_name": "",
        "draft_personality": list(PERSONALITIES.keys())[0],
        "draft_background": list(BACKGROUNDS.keys())[0],
        "draft_physical": list(PHYSICAL_STATES.keys())[0],
        "draft_mood": list(STARTING_MOODS.keys())[0],
        "mode": "normal",
        "follow_up_node": None,
        "follow_up_parent": None,
        "last_initiative_turn": -1,
        "free_text_input": "",
        "clear_text": False,
        "recent_speech_norms": [],
        "last_free_text_category": None,
        "aggressive_free_text_count": 0,
        "free_text_cat_mode_active": False,
        "crow_brain": {},
        "crow_brain_last_variant": {},
        "crow_brain_last_attitude": None,
        "crow_brain_step": 0,
        "conversation_memory": init_memory_state(),
        "human_variation": init_human_variation_state(),
        "dna_seed": random.randint(1, 10_000_000),
        "character_dna": {},
        "identity_state": init_identity_state(),
        # Crow Brain debug card: off unless set True in code (no UI toggle).
        "show_debug_crow_brain": False,
        RECENT_INTENTS_KEY: [],
        LAST_STALL_CHECK_KEY: "",
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def reset_flow():
    st.session_state.page = "builder"
    st.session_state.character_built = False
    st.session_state.history = []
    st.session_state.turns = 0
    st.session_state.last_deltas = {k: 0 for k in ATTRIBUTES}
    st.session_state.repeat_counts = {}
    st.session_state.action_repeat_counts = {}
    st.session_state.conversation_over = False
    st.session_state.ending_message = ""
    st.session_state.build_snapshot = {}
    st.session_state.selected_scenario = list(SCENARIOS.keys())[0]
    st.session_state.state = deepcopy(BASE_STATE)
    st.session_state.mode = "normal"
    st.session_state.follow_up_node = None
    st.session_state.follow_up_parent = None
    st.session_state.last_initiative_turn = -1
    st.session_state.clear_text = True
    st.session_state.recent_speech_norms = []
    st.session_state.last_free_text_category = None
    st.session_state.aggressive_free_text_count = 0
    st.session_state.free_text_cat_mode_active = False
    st.session_state.crow_brain_last_variant = {}
    st.session_state.crow_brain_last_attitude = None
    st.session_state.crow_brain_step = 0
    st.session_state.conversation_memory = init_memory_state()
    st.session_state.human_variation = init_human_variation_state()
    st.session_state.character_dna = {}
    st.session_state.identity_state = init_identity_state()
    st.session_state[RECENT_INTENTS_KEY] = []
    st.session_state[LAST_STALL_CHECK_KEY] = ""
    reset_menu_emotional_pressure()


def maybe_character_initiates():
    """Sometimes the character drives: asks a question, shifts topic."""
    if st.session_state.conversation_over:
        return
    if st.session_state.mode == "follow_up":
        return
    if st.session_state.turns < 2:
        return
    if st.session_state.turns == st.session_state.last_initiative_turn:
        return
    if random.random() > 0.18:  # 18% chance after eligible turns
        return
    state = st.session_state.state
    if state["anger"] > 65 or state["trust"] < 15:  # don't initiate when hostile
        return
    q, mods, physical, vibe = random.choice(CHARACTER_INITIATIVES)
    scale = SCENARIOS[st.session_state.selected_scenario]["sensitivity"]
    apply_mods_with_identity(st.session_state.state, mods, scale, kind="do")
    st.session_state.last_initiative_turn = st.session_state.turns
    brain = crow_brain_interpret(
        st.session_state.state,
        user_input=q,
        kind="character_initiative",
        repeat_count=st.session_state.turns,
    )
    st.session_state.crow_brain = brain
    st.session_state.history.insert(0, {
        "type": "They asked",
        "input": "",
        "verbal": quote(q),
        "tone": brain["tone"],
        "physical": brain["physical_reaction"],
        "vibe": brain["vibe"],
    })


def start_scenario(name):
    st.session_state.character_name = st.session_state.draft_name.strip() or "Character"
    st.session_state.selected_scenario = name
    st.session_state.state = build_state(
        st.session_state.draft_personality,
        st.session_state.draft_background,
        st.session_state.draft_physical,
        st.session_state.draft_mood,
        name,
    )
    st.session_state.character_dna = generate_personality_dna(
        st.session_state.draft_personality,
        st.session_state.draft_background,
        st.session_state.draft_physical,
        st.session_state.draft_mood,
        st.session_state.character_name,
        jitter_seed=st.session_state.get("dna_seed", 0),
    )
    st.session_state.identity_state = init_identity_state()
    st.session_state.character_built = True
    st.session_state.history = []
    st.session_state.turns = 0
    st.session_state.last_deltas = {k: 0 for k in ATTRIBUTES}
    st.session_state.repeat_counts = {}
    st.session_state.action_repeat_counts = {}
    st.session_state.conversation_over = False
    st.session_state.ending_message = ""
    st.session_state.mode = "normal"
    st.session_state.follow_up_node = None
    st.session_state.follow_up_parent = None
    st.session_state.last_initiative_turn = -1
    st.session_state.clear_text = True
    st.session_state.recent_speech_norms = []
    st.session_state.last_free_text_category = None
    st.session_state.aggressive_free_text_count = 0
    st.session_state.free_text_cat_mode_active = False
    st.session_state.crow_brain = {}
    st.session_state.crow_brain_last_variant = {}
    st.session_state.crow_brain_last_attitude = None
    st.session_state.crow_brain_step = 0
    st.session_state.conversation_memory = init_memory_state()
    st.session_state.human_variation = init_human_variation_state()
    st.session_state.build_snapshot = {
        "Personality": st.session_state.draft_personality,
        "Background": st.session_state.draft_background,
        "Physical": st.session_state.draft_physical,
        "Mood": st.session_state.draft_mood,
        "Environment": name,
    }
    st.session_state[RECENT_INTENTS_KEY] = []
    st.session_state[LAST_STALL_CHECK_KEY] = ""
    reset_menu_emotional_pressure()
    st.session_state.page = "interact"


def murder_vibes(verbal, input_text, kind, physical_override=None):
    old_state = deepcopy(st.session_state.state)
    murdered_state(st.session_state.state)
    st.session_state.last_deltas = {k: st.session_state.state[k] - old_state[k] for k in ATTRIBUTES}
    st.session_state.conversation_over = True
    st.session_state.ending_message = "VIBES MURDERED"
    st.session_state.mode = "normal"
    st.session_state.follow_up_node = None
    st.session_state.follow_up_parent = None
    st.session_state.history.insert(0, {
        "type": "You said" if kind == "say" else "You did",
        "input": input_text,
        "verbal": verbal,
        "tone": "hostile",
        "physical": physical_override or "looks furious, turns away, and storms off",
        "vibe": "murdered",
    })


def enter_follow_up(node_key, parent_label=None):
    st.session_state.mode = "follow_up"
    st.session_state.follow_up_node = node_key
    st.session_state.follow_up_parent = parent_label


def resolve_follow_up_choice(option_text, mods, verbal, next_node):
    if st.session_state.conversation_over:
        return
    scale = SCENARIOS[st.session_state.selected_scenario]["sensitivity"]
    old_state = deepcopy(st.session_state.state)
    apply_mods_with_identity(st.session_state.state, mods, scale, kind="follow_up")
    st.session_state.last_deltas = {k: st.session_state.state[k] - old_state[k] for k in ATTRIBUTES}
    st.session_state.turns += 1

    if next_node == "END_MURDER":
        murder_vibes(verbal, option_text, "say")
        return

    mem = st.session_state.get("conversation_memory") or init_memory_state()
    # Track follow-up answers for light contradiction/suspicion heuristics
    mem["followup_answers"] = (mem.get("followup_answers") or []) + [str(option_text)]
    mem["followup_answers"] = mem["followup_answers"][-8:]
    # Simple contradiction: praise then "never listened" / "idk" in same arc
    low = str(option_text).lower()
    if "i don't listen" in low or "never listened" in low:
        if any("they're great" in str(x).lower() or "they are great" in str(x).lower() for x in mem["followup_answers"][:-1]):
            mem["inconsistency_score"] = clamp(mem.get("inconsistency_score", 0) + 6, 0, 100)
            mem["honesty_score"] = clamp(mem.get("honesty_score", 50) - 4, 0, 100)
    if any(x in low for x in ("i don't know", "whatever", "you decide")):
        mem["pressure_score"] = clamp(mem.get("pressure_score", 0) + 1, 0, 100)
        mem["honesty_score"] = clamp(mem.get("honesty_score", 50) - 1, 0, 100)
    st.session_state.conversation_memory = mem
    update_conversation_memory(mem, option_text, "follow_up", False, None, 1, scenario_name=st.session_state.selected_scenario)

    st.session_state[SESSION_MODE_KEY] = resolve_response_mode(option_text, st.session_state.state)

    brain = crow_brain_interpret(
        st.session_state.state,
        user_input=option_text,
        kind="follow_up",
        repeat_count=st.session_state.turns,
    )
    st.session_state.crow_brain = brain
    tone = brain["tone"]
    vibe = brain["vibe"]
    physical = brain["physical_reaction"]
    verbal = crow_brain_apply_to_verbal(
        verbal,
        brain,
        st.session_state.state,
        user_input=option_text,
        turns_before_reply=st.session_state.turns,
    )
    st.session_state.history.insert(0, {
        "type": "You answered",
        "input": option_text,
        "verbal": verbal,
        "tone": tone,
        "physical": physical,
        "vibe": vibe,
    })
    record_last_response_for_stall_gate(verbal)

    if next_node:
        enter_follow_up(next_node, st.session_state.follow_up_parent)
    else:
        st.session_state.mode = "normal"
        st.session_state.follow_up_node = None
        st.session_state.follow_up_parent = None


def maybe_start_follow_up(choice):
    personality = st.session_state.build_snapshot.get("Personality", "Confident")
    bucket = choose_bucket(st.session_state.state, personality)
    if choice == "Do you want to go on a date?":
        if bucket == "positive":
            st.session_state.history.insert(0, {
                "type": "You said",
                "input": choice,
                "verbal": quote("Yeah, I'd like that. Where should we go?"),
                "tone": "warm",
                "physical": "leans in and actually seems interested",
                "vibe": "promising",
            })
            enter_follow_up("date_where", choice)
            return True
        if bucket == "neutral":
            st.session_state.history.insert(0, {
                "type": "You said",
                "input": choice,
                "verbal": quote("Sure. What did you have in mind?"),
                "tone": "neutral",
                "physical": "keeps posture relaxed but waits to hear your answer",
                "vibe": "open but evaluating",
            })
            enter_follow_up("date_neutral", choice)
            return True
    if choice == "Would you like to buy my jetski?":
        st.session_state.history.insert(0, {
            "type": "You said",
            "input": choice,
            "verbal": quote("Hmm… how much?"),
            "tone": "engaged",
            "physical": "raises an eyebrow and actually considers it",
            "vibe": "curious but suspicious",
        })
        enter_follow_up("jetski_price", choice)
        return True
    if choice == "Is Playboi Carti overrated?":
        if random.random() < 0.35:
            st.session_state.history.insert(0, {
                "type": "You said",
                "input": choice,
                "verbal": quote("Forget Carti for a second. Do you like Nirvana?"),
                "tone": "engaged",
                "physical": "tilts head and waits for your take",
                "vibe": "suddenly more specific",
            })
            enter_follow_up("nirvana_question", choice)
        else:
            bucket = choose_bucket(st.session_state.state)
            if bucket == "positive":
                verbal = quote("Carti has moments. Overrated is too lazy.")
            elif bucket == "neutral":
                verbal = quote("Sometimes yes. Sometimes people just hate fun.")
            elif bucket == "negative":
                verbal = quote("Probably. But I don't trust your taste either.")
            else:
                verbal = quote("What do you think this is? I'm the one asking the questions. Give me your opinion on Carti before I freak out.")
            st.session_state.history.insert(0, {
                "type": "You said",
                "input": choice,
                "verbal": verbal,
                "tone": infer_tone(st.session_state.state),
                "physical": "furrows brow and waits for your answer",
                "vibe": "specific and slightly combative",
            })
        return True
    return False


def process_interaction(choice, kind, is_free_text=False):
    if st.session_state.conversation_over:
        return

    st.session_state[SESSION_MODE_KEY] = {}

    scale = SCENARIOS[st.session_state.selected_scenario]["sensitivity"]
    old_state = deepcopy(st.session_state.state)

    if kind == "say":
        free_category = None
        cat_mode = False
        norm = normalize_speech(choice)
        recent_list = list(st.session_state.get("recent_speech_norms", []))
        prev_free = st.session_state.get("last_free_text_category")
        if is_free_text:
            cat_raw = interpret_free_text(choice)
            prev_fc = st.session_state.get("last_free_text_category")
            n_aggr_pre = st.session_state.get("aggressive_free_text_count", 0)
            free_category = cat_raw
            if (
                prev_fc
                and str(prev_fc).startswith("aggressive_")
                and free_category
                and str(free_category).startswith("aggressive_")
            ):
                bumped = {
                    "aggressive_light": "aggressive_medium",
                    "aggressive_medium": "aggressive_hard",
                }.get(free_category, free_category)
                if bumped == "aggressive_hard" and free_text_weak_insult_phrase(choice):
                    free_category = "aggressive_medium"
                else:
                    free_category = bumped
            cat_mode = should_use_cat_mode(choice, free_category, cat_raw, prev_fc, n_aggr_pre, recent_list)
        echo = speech_echoes_recent(
            norm, recent_list, is_free_text, prev_free, free_category if is_free_text else None
        )

        count = st.session_state.repeat_counts.get(choice, 0) + 1
        st.session_state.repeat_counts[choice] = count

        mem = st.session_state.get("conversation_memory") or init_memory_state()
        update_conversation_memory(
            mem,
            choice,
            kind,
            is_free_text,
            free_category if is_free_text else None,
            count,
            scenario_name=st.session_state.selected_scenario,
        )
        st.session_state.conversation_memory = mem

        st.session_state["_speech_echo_this_turn"] = echo
        st.session_state[SESSION_MODE_KEY] = resolve_response_mode(choice, st.session_state.state)

        _soft_rep = (st.session_state.get(SESSION_MODE_KEY) or {}).get("soft_echo_penalty")
        if count == 2:
            r2 = {"trust": -8, "confusion": 6, "happiness": -4}
            if _soft_rep:
                r2 = {"trust": -5, "confusion": 2, "happiness": -2}
            apply_mods_with_identity(st.session_state.state, r2, scale, kind=kind)
        elif count == 3:
            r3 = {"trust": -14, "anger": 8, "stress": 6, "happiness": -8}
            if _soft_rep:
                r3 = {"trust": -8, "anger": 4, "stress": 3, "happiness": -4}
            apply_mods_with_identity(st.session_state.state, r3, scale, kind=kind)
        elif count == 4:
            r4 = {"trust": -18, "anger": 12, "stress": 10, "interest": -10, "happiness": -10}
            if _soft_rep:
                r4 = {"trust": -10, "anger": 6, "stress": 5, "interest": -5, "happiness": -5}
            apply_mods_with_identity(st.session_state.state, r4, scale, kind=kind)
        elif count >= 5:
            r5 = {"trust": -24, "anger": 18, "stress": 16, "interest": -18, "happiness": -12}
            if _soft_rep:
                r5 = {"trust": -12, "anger": 8, "stress": 8, "interest": -8, "happiness": -6}
            apply_mods_with_identity(st.session_state.state, r5, scale, kind=kind)

        echo_mods = {"trust": -5, "confusion": 4, "stress": 2, "happiness": -2}
        if (st.session_state.get(SESSION_MODE_KEY) or {}).get("soft_echo_penalty"):
            echo_mods = {"trust": -3, "confusion": 1, "stress": 0, "happiness": -1}

        sassy_free = bool(
            is_free_text
            and (
                cat_mode
                or (free_category and str(free_category).startswith("aggressive_"))
            )
        )
        if count == 1:
            if echo:
                apply_mods_with_identity(st.session_state.state, echo_mods, scale, kind=kind)
                if is_free_text:
                    if cat_mode:
                        base_fc = dict(CAT_MODE_FREE_TEXT_EFFECTS)
                    else:
                        base_fc = scaled_free_text_category_mods(free_category)
                    scaled = scale_stat_mods(base_fc, 0.42)
                    apply_mods_with_identity(
                        st.session_state.state,
                        scaled,
                        scale,
                        kind=kind,
                        free_text_category=free_category,
                        sassy_comeback=sassy_free,
                    )
                else:
                    sm = _scaled_menu_say_mods(choice)
                    if sm:
                        apply_mods_with_identity(st.session_state.state, sm, scale, kind=kind)
            elif is_free_text:
                if cat_mode:
                    mods = dict(CAT_MODE_FREE_TEXT_EFFECTS)
                else:
                    mods = scaled_free_text_category_mods(free_category)
                apply_mods_with_identity(
                    st.session_state.state,
                    mods,
                    scale,
                    kind=kind,
                    free_text_category=free_category,
                    sassy_comeback=sassy_free,
                )
            else:
                sm_menu = _scaled_menu_say_mods(choice)
                if sm_menu:
                    apply_mods_with_identity(st.session_state.state, sm_menu, scale, kind=kind)
        else:
            repeat_drag = {"happiness": -3, "trust": -4, "stress": 3, "anger": 3}
            if count >= 3:
                repeat_drag["interest"] = -4
            if (st.session_state.get(SESSION_MODE_KEY) or {}).get("soft_echo_penalty"):
                repeat_drag = {"happiness": -2, "trust": -2, "stress": 1, "anger": 1}
                if count >= 3:
                    repeat_drag["interest"] = -2
            apply_mods_with_identity(st.session_state.state, repeat_drag, scale, kind=kind)

        _rm = st.session_state.get(SESSION_MODE_KEY) or {}
        if _rm.get("apply_stat_relief"):
            apply_question_type_stat_relief(
                st.session_state.state, _rm.get("question_type", ""), scale
            )
        if _rm.get("grounded_inquiry_relief"):
            apply_mods(st.session_state.state, {"confusion": -10, "stress": -4}, scale)

        def record_speech_memory():
            rl = list(st.session_state.get("recent_speech_norms", []))
            rl.append(norm)
            st.session_state.recent_speech_norms = rl[-4:]
            if is_free_text:
                st.session_state.last_free_text_category = free_category
                if free_category and str(free_category).startswith("aggressive_"):
                    st.session_state.aggressive_free_text_count = int(
                        st.session_state.get("aggressive_free_text_count", 0)
                    ) + 1

        if count >= 5:
            record_speech_memory()
            murder_vibes(quote("You literally just said that again. I'm done with this."), choice, kind)
            return

        # Crow Brain: generate internal thought after emotion changes, before response selection
        st.session_state.crow_brain = crow_brain_interpret(
            st.session_state.state,
            user_input=choice,
            kind=kind,
            free_text_category=free_category if is_free_text else None,
            repeat_count=count,
        )
        _brain_now = st.session_state.get("crow_brain") or {}
        st.session_state["_fi_lock_verbal"] = first_impression_verbal_locked(
            choice,
            st.session_state.turns,
            st.session_state.state,
            _brain_now.get("attitude", "guarded"),
        )

        if maybe_start_follow_up(choice):
            record_speech_memory()
            st.session_state.last_deltas = {k: st.session_state.state[k] - old_state[k] for k in ATTRIBUTES}
            st.session_state.turns += 1
            return

        personality = st.session_state.build_snapshot.get("Personality", "Confident")
        st.session_state.free_text_cat_mode_active = bool(cat_mode)
        try:
            verbal, tone, physical, vibe = build_response(
                choice,
                kind,
                st.session_state.state,
                st.session_state.character_name,
                st.session_state.selected_scenario,
                personality,
                free_text_category=free_category,
                turns_before_reply=st.session_state.turns,
                starting_mood=(st.session_state.build_snapshot or {}).get("Mood", "Neutral"),
            )
        finally:
            st.session_state.free_text_cat_mode_active = False

        repetition_light = [
            "Didn't you just ask me that?",
            "You already asked that.",
            "Yeah—same answer.",
            "We literally just covered this.",
        ]
        repetition_mid = repetition_light + [
            "Didn't you just say that?",
            "You're repeating yourself.",
            "I already answered that.",
        ]
        ag_free = bool(
            is_free_text and free_category and str(free_category).startswith("aggressive_")
        )
        if count == 1 and echo:
            verbal = quote(random.choice(repetition_light))
            tone = infer_tone(st.session_state.state)
            if tone == "warm":
                tone = "uncertain"
            vibe = "weirdly familiar"
            physical = "gives you a look like you're looping"
        elif count == 2 and not ag_free:
            verbal = quote(random.choice(repetition_mid))
        elif count == 3 and not ag_free:
            verbal = quote(random.choice([
                "You're repeating yourself.",
                "Okay, you're stuck on repeat.",
                "I heard you the first two times.",
            ]))
        elif count == 4 and not ag_free:
            warnings = [
                "If you keep doing this, I'm going to leave.",
                "Please stop. This is getting irritating.",
                "I don't know what you're doing here, but it is not going well.",
            ]
            verbal = quote(random.choice(warnings))
            tone = "hostile"
            vibe = "vibe slipping"
            physical = "looks irritated and starts pulling away"

        # Finalize response through Crow Brain (tone/physical must match internal state)
        brain = st.session_state.get("crow_brain") or {}
        verbal = crow_brain_apply_to_verbal(
            verbal,
            brain,
            st.session_state.state,
            user_input=choice,
            free_text_category=free_category if is_free_text else None,
            turns_before_reply=st.session_state.turns,
        )
        tone = brain.get("tone", tone)
        physical = brain.get("physical_reaction", physical)
        vibe = brain.get("vibe", vibe)

        record_speech_memory()
        st.session_state.last_deltas = {k: st.session_state.state[k] - old_state[k] for k in ATTRIBUTES}
        st.session_state.turns += 1
        st.session_state.history.insert(0, {
            "type": "You said",
            "input": choice,
            "verbal": verbal,
            "tone": tone,
            "physical": physical,
            "vibe": vibe,
        })
        record_last_response_for_stall_gate(verbal)
        if not is_free_text:
            _mt = st.session_state.get(SESSION_MODE_KEY) or {}
            _esub = _mt.get("emotional_subtype", PRESSURE_DEFAULT)
            record_menu_emotional_turn(choice, str(_esub))
            if _mt.get("question_type") == EMOTIONAL_PRESSURE or _esub in (
                ROMANTIC_PRESSURE,
                VALIDATION_SEEKING,
            ):
                register_emotional_menu_prompt(choice)
        if verbal_triggers_conversation_shutdown(verbal):
            st.session_state.conversation_over = True
            st.session_state.ending_message = "CONVERSATION ENDED"
            st.session_state.mode = "normal"
            st.session_state.follow_up_node = None
            st.session_state.follow_up_parent = None
            return
        maybe_character_initiates()

    else:
        count = st.session_state.action_repeat_counts.get(choice, 0) + 1
        st.session_state.action_repeat_counts[choice] = count
        mem = st.session_state.get("conversation_memory") or init_memory_state()
        # Actions can apply pressure/awkward residue too.
        if choice in {"Step closer", "Stare blankly", "Interrupt", "Raise voice"}:
            mem["pressure_score"] = clamp(mem.get("pressure_score", 0) + (2 if choice == "Step closer" else 3), 0, 100)
            mem["awkward_score"] = clamp(mem.get("awkward_score", 0) + (2 if choice == "Stare blankly" else 1), 0, 100)
        if choice == "Smile" and mem.get("last_turn_was_rude"):
            mem["inconsistency_score"] = clamp(mem.get("inconsistency_score", 0) + 2, 0, 100)
            mem["honesty_score"] = clamp(mem.get("honesty_score", 50) - 1, 0, 100)
        st.session_state.conversation_memory = mem
        # Repeated Smile: happiness drops as it gets weird (count 2+)
        if choice == "Smile" and count >= 2:
            smile_repeat_mods = {
                2: {"confusion": 6, "happiness": -6, "trust": -2},
                3: {"trust": -10, "stress": 6, "happiness": -8, "anger": 4},
                4: {"trust": -14, "anger": 10, "stress": 10, "happiness": -12},
            }
            mods = smile_repeat_mods.get(count, {"trust": -18, "anger": 14, "stress": 12, "happiness": -14})
            apply_mods_with_identity(st.session_state.state, mods, scale, kind=kind)
        # Step closer repeated: negative reaction = happiness down, anger up, trust down, stress up
        elif choice == "Step closer" and count >= 2:
            step_closer_mods = {
                2: {"happiness": -6, "anger": 6, "trust": -8, "stress": 6},   # "Woah there" - tense
                3: {"happiness": -10, "anger": 12, "trust": -12, "stress": 10},  # "I said back up" - hostile
            }
            mods = step_closer_mods.get(count, {"happiness": -12, "anger": 14, "trust": -14, "stress": 12})
            apply_mods_with_identity(st.session_state.state, mods, scale, kind=kind)
        else:
            apply_mods_with_identity(st.session_state.state, ACTION_OPTIONS[choice], scale, kind=kind)
        personality = st.session_state.build_snapshot.get("Personality", "Confident")
        st.session_state.crow_brain = crow_brain_interpret(
            st.session_state.state,
            user_input=choice,
            kind="do",
            free_text_category=None,
            repeat_count=count,
        )
        verbal, tone, physical, vibe, ended = action_reaction(
            choice, count, st.session_state.state, personality, before_state=old_state
        )

        if ended:
            murder_vibes(verbal, choice, kind, physical_override=physical)
            return

        # Finalize response through Crow Brain (tone/physical must match internal state)
        brain = st.session_state.get("crow_brain") or {}
        verbal = crow_brain_apply_to_verbal(
            verbal,
            brain,
            st.session_state.state,
            user_input=choice,
            turns_before_reply=st.session_state.turns,
        )
        tone = brain.get("tone", tone)
        physical = brain.get("physical_reaction", physical)
        vibe = brain.get("vibe", vibe)

        st.session_state.last_deltas = {k: st.session_state.state[k] - old_state[k] for k in ATTRIBUTES}
        st.session_state.turns += 1
        st.session_state.history.insert(0, {
            "type": "You did",
            "input": choice,
            "verbal": verbal,
            "tone": tone,
            "physical": physical,
            "vibe": vibe,
        })
        record_last_response_for_stall_gate(verbal)
        maybe_character_initiates()


set_defaults()
ui_app_css(st)

if st.session_state.page == "builder":
    st.markdown('<div class="main-title">Silver Crow</div>', unsafe_allow_html=True)
    st.markdown('<div class="subtitle">Create the person. Choose the moment. Step in.</div>', unsafe_allow_html=True)

    left, right = st.columns([1.12, 0.88], gap="large")
    with left:
        st.markdown('<div class="builder-title">Character builder</div>', unsafe_allow_html=True)
        st.markdown('<div class="builder-sub">Who are you meeting?</div>', unsafe_allow_html=True)
        st.session_state.draft_name = st.text_input("Character name", value=st.session_state.draft_name)
        st.session_state.draft_personality = st.selectbox("Personality type", list(PERSONALITIES.keys()), index=list(PERSONALITIES.keys()).index(st.session_state.draft_personality))
        st.session_state.draft_background = st.selectbox("Background", list(BACKGROUNDS.keys()), index=list(BACKGROUNDS.keys()).index(st.session_state.draft_background))
        st.session_state.draft_physical = st.selectbox("Physical state", list(PHYSICAL_STATES.keys()), index=list(PHYSICAL_STATES.keys()).index(st.session_state.draft_physical))
        st.session_state.draft_mood = st.selectbox("Starting mood", list(STARTING_MOODS.keys()), index=list(STARTING_MOODS.keys()).index(st.session_state.draft_mood))
        c1, c2 = st.columns(2)
        with c1:
            if st.button("Continue to scenario", use_container_width=True):
                st.session_state.page = "scenario"
                st.rerun()
        with c2:
            if st.button("Reset all", use_container_width=True):
                reset_flow()
                st.session_state.draft_name = ""
                st.session_state.draft_personality = list(PERSONALITIES.keys())[0]
                st.session_state.draft_background = list(BACKGROUNDS.keys())[0]
                st.session_state.draft_physical = list(PHYSICAL_STATES.keys())[0]
                st.session_state.draft_mood = list(STARTING_MOODS.keys())[0]
                st.rerun()


    with right:
        preview_name = st.session_state.draft_name.strip() or "Character"
        preview_state = build_state(
            st.session_state.draft_personality,
            st.session_state.draft_background,
            st.session_state.draft_physical,
            st.session_state.draft_mood,
            list(SCENARIOS.keys())[0],
        )
        avatar = get_avatar(st.session_state.draft_personality, preview_state)
        st.markdown('<div class="section-title">Preview</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="hero-avatar">{avatar}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="hero-name">{preview_name}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="summary-line"><b>Personality:</b> {st.session_state.draft_personality}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="summary-line"><b>Background:</b> {st.session_state.draft_background}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="summary-line"><b>Physical:</b> {st.session_state.draft_physical}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="summary-line"><b>Mood:</b> {st.session_state.draft_mood}</div>', unsafe_allow_html=True)
        st.markdown('<div class="tiny">Scenario comes next.</div>', unsafe_allow_html=True)

elif st.session_state.page == "scenario":
    st.markdown('<div class="main-title">Choose scenario</div>', unsafe_allow_html=True)
    st.markdown('<div class="subtitle">Where does this happen?</div>', unsafe_allow_html=True)

    top1, top2 = st.columns([1,5])
    with top1:
        if st.button("← Back", use_container_width=True):
            st.session_state.page = "builder"
            st.rerun()
    with top2:
        st.markdown(
            f'<div class="tiny"><b>{st.session_state.draft_name.strip() or "Character"}</b> · '
            f'{st.session_state.draft_personality} · {st.session_state.draft_background}</div>',
            unsafe_allow_html=True,
        )

    scenario_items = list(SCENARIOS.items())
    for row_start in range(0, len(scenario_items), 3):
        row = scenario_items[row_start:row_start+3]
        cols = st.columns(3, gap="medium")
        for col, item in zip(cols, row):
            name, cfg = item
            with col:
                st.markdown(f"### {name}")
                st.write(cfg["desc"])
                if st.button(f"Enter {name}", key=f"enter_{name}", use_container_width=True):
                    start_scenario(name)
                    st.rerun()
        if len(row) < 3:
            for col in cols[len(row):]:
                with col:
                    st.markdown("&nbsp;", unsafe_allow_html=True)

else:
    if st.session_state.conversation_over:
        st.markdown(
            f"""
            <div class="gameover" id="gameover-section">
                <div class="gameover-big">{st.session_state.ending_message or "VIBES MURDERED"}</div>
                <div class="gameover-small">What now?</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.markdown('<div class="recovery-buttons-marker" aria-hidden="true" style="height:0;overflow:hidden;"></div>', unsafe_allow_html=True)
        a, b, c = st.columns(3)
        with a:
            if st.button("Try again", key="gameover_try_again", use_container_width=True):
                start_scenario(st.session_state.selected_scenario)
                st.rerun()
        with b:
            if st.button("Different scenario", key="gameover_scenario", use_container_width=True):
                st.session_state.page = "scenario"
                st.session_state.conversation_over = False
                st.session_state.ending_message = ""
                st.session_state.mode = "normal"
                st.session_state.follow_up_node = None
                st.session_state.follow_up_parent = None
                st.rerun()
        with c:
            if st.button("Someone new", key="gameover_new", use_container_width=True):
                reset_flow()
                st.rerun()

    cols = st.columns([1.02, 1.12, 0.92], gap="medium")
    left, middle, right = cols

    with left:
        if st.session_state.mode == "follow_up" and st.session_state.follow_up_node in FOLLOW_UP_NODES:
            node = FOLLOW_UP_NODES[st.session_state.follow_up_node]
            st.markdown('<div class="follow-card">', unsafe_allow_html=True)
            st.markdown(f'<div class="follow-question">{node["question"]}</div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)
            for idx, (label, mods, verbal, next_node) in enumerate(node["options"]):
                st.button(
                    label,
                    key=f"follow_{st.session_state.follow_up_node}_{idx}",
                    use_container_width=True,
                    on_click=resolve_follow_up_choice,
                    args=(label, mods, verbal, next_node),
                )
        else:
            st.markdown('<div class="section-title">Speak</div>', unsafe_allow_html=True)
            scenario_name = st.session_state.selected_scenario
            say_pool = get_say_options_for_scenario(scenario_name) or DEFAULT_SAY_OPTIONS
            say_choice = st.selectbox(
                " ",
                list(say_pool.keys()),
                key="say_choice",
                label_visibility="collapsed",
            )
            if "clear_text" not in st.session_state:
                st.session_state.clear_text = False
            if st.session_state.clear_text:
                st.session_state.free_text_input = ""
                st.session_state.clear_text = False
            st.text_input("Or say whatever:", key="free_text_input", placeholder="Type something...", label_visibility="visible")
            say_clicked = st.button("Say it", key="send_line", use_container_width=True)
            if say_clicked:
                typed = (st.session_state.get("free_text_input") or "").strip()
                default_fallback = next(iter(say_pool.keys()), None)
                choice = typed if typed else st.session_state.get("say_choice", default_fallback)
                is_free = bool(typed)
                process_interaction(choice, "say", is_free_text=is_free)
                if is_free:
                    st.session_state.clear_text = True
                st.rerun()

            st.markdown('<div class="section-title section-title--spaced">Act</div>', unsafe_allow_html=True)
            act_choice = st.selectbox(" ", list(ACTION_OPTIONS.keys()), key="action_choice", label_visibility="collapsed")
            st.button("Do it", key="do_action", use_container_width=True, on_click=process_interaction, args=(act_choice, "do"))

        snap = st.session_state.get("build_snapshot") or {}
        if snap:
            p, bg, phy, mood = (
                html.escape(str(snap.get("Personality", "—"))),
                html.escape(str(snap.get("Background", "—"))),
                html.escape(str(snap.get("Physical", "—"))),
                html.escape(str(snap.get("Mood", "—"))),
            )
            card_name = html.escape((st.session_state.character_name or "").strip() or "Character")
            st.markdown(
                '<div class="character-sheet">'
                f'<div class="character-card-name">{card_name}</div>'
                f'<div class="character-sheet-line"><span class="cs-k">Personality</span> {p}</div>'
                f'<div class="character-sheet-line"><span class="cs-k">Mood</span> {mood}</div>'
                f'<div class="character-sheet-line"><span class="cs-k">Background</span> {bg}</div>'
                f'<div class="character-sheet-line"><span class="cs-k">Physical</span> {phy}</div>'
                "</div>",
                unsafe_allow_html=True,
            )

    with middle:
        personality = st.session_state.build_snapshot.get("Personality", "Confident")
        murdered = st.session_state.conversation_over
        avatar = get_avatar(personality, st.session_state.state, murdered=murdered)
        if not st.session_state.history:
            hero_text = ""
            you_context = ""
            vibe = "quiet"
            tone = "neutral"
            physical = ""
        else:
            item = st.session_state.history[0]
            hero_text = item["verbal"] if item["verbal"] else ""
            if item["type"] == "They asked":
                their_line = strip_outer_quotes(item.get("verbal") or "").strip()
                if their_line:
                    you_context = f'They said: {html.escape(their_line)}'
                else:
                    you_context = "They spoke first."
            elif item["type"] in ("You said", "You answered"):
                you_context = f"You: {html.escape(str(item.get('input') or ''))}"
            else:
                you_context = f"You: {html.escape(str(item.get('input') or ''))}"
            vibe = item["vibe"]
            tone = item["tone"]
            physical = str(item.get("physical") or "").strip()

        st.markdown(f'<div class="hero-avatar">{avatar}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="hero-name">{st.session_state.character_name}</div>', unsafe_allow_html=True)
        hero_safe = html.escape(hero_text) if hero_text else ""
        st.markdown(
            f'<div class="hero-response">{hero_safe if hero_safe else "&#160;"}</div>',
            unsafe_allow_html=True,
        )
        if you_context:
            st.markdown(f'<div class="meta-line meta-line--you">{you_context}</div>', unsafe_allow_html=True)
        if vibe != "quiet":
            st.markdown(
                f'<div class="meta-line meta-line--state"><b>Vibe:</b> {html.escape(str(vibe))} · '
                f'<b>Tone:</b> {html.escape(str(tone))}</div>',
                unsafe_allow_html=True,
            )
        if physical:
            st.markdown(
                f'<div class="meta-line meta-line--physical"><b>Physical:</b> {html.escape(physical)}</div>',
                unsafe_allow_html=True,
            )


    with right:
        scenario_name = st.session_state.selected_scenario
        st.markdown(
            f'<div class="scenario-head">{html.escape(scenario_name)}</div>',
            unsafe_allow_html=True,
        )
        rel = relationship_status(st.session_state.state, st.session_state.conversation_over)
        st.markdown(
            f'<div class="meta-line meta-line--status"><b>Between you:</b> '
            f'<span class="relationship-pill">{html.escape(rel)}</span></div>',
            unsafe_allow_html=True,
        )

        if st.session_state.get("show_debug_crow_brain"):
            brain = st.session_state.get("crow_brain") or {}
            internal_thought = html.escape(str(brain.get("internal_thought", "")))
            attitude = html.escape(str(brain.get("attitude", "")))
            tone = html.escape(str(brain.get("tone", "")))
            physical = html.escape(str(brain.get("physical_reaction", "")))
            read_on_you = html.escape(str(brain.get("user_read", ""))) or html.escape(
                derive_read_on_you(st.session_state.get("conversation_memory") or init_memory_state())
            )
            trend = html.escape(str(brain.get("relationship_trend", "")))
            traj = html.escape(str(brain.get("interaction_trajectory", "")))
            if internal_thought or attitude:
                trend_html = f'<div class="crow-brain-line"><b>Trend:</b> {trend}</div>' if trend else ""
                traj_html = f'<div class="crow-brain-line"><b>Direction:</b> {traj}</div>' if traj else ""
                st.markdown(
                    '<div class="crow-brain-card">'
                    '<div class="crow-brain-title">Crow Brain</div>'
                    f'<div class="crow-brain-line"><b>Internal Thought:</b> {internal_thought}</div>'
                    f'<div class="crow-brain-line"><b>Read On You:</b> {read_on_you}</div>'
                    f'{trend_html}'
                    f'{traj_html}'
                    f'<div class="crow-brain-line"><b>Attitude:</b> {attitude}</div>'
                    f'<div class="crow-brain-line"><b>Tone:</b> {tone}</div>'
                    f'<div class="crow-brain-line"><b>Physical:</b> {physical}</div>'
                    "</div>",
                    unsafe_allow_html=True,
                )

        r1, r2 = st.columns(2, gap="small")
        half = (len(ATTRIBUTES) + 1) // 2
        chunks = [ATTRIBUTES[:half], ATTRIBUTES[half:]]
        for col, chunk in zip([r1, r2], chunks):
            with col:
                for attr in chunk:
                    value = int(st.session_state.state[attr])
                    pct = max(0, min(100, value))
                    label = attr.capitalize()
                    delta = int(st.session_state.last_deltas.get(attr, 0))
                    color = attribute_color(attr, delta)
                    delta_html = f' <span style="color:{color};font-size:0.85em;font-weight:800;">{format_delta(delta)}</span>' if delta != 0 else ''
                    st.markdown(
                        f'<div class="stat-row">'
                        f'<div class="stat-label-line"><b>{label}:</b> <span class="stat-value">{value}</span>{delta_html}</div>'
                        f'<div class="stat-bar-track"><div class="stat-bar-fill" style="width:{pct}%;"></div></div>'
                        f"</div>",
                        unsafe_allow_html=True,
                    )
