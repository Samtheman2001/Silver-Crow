"""
Response/outcome helpers that aren't the core brain logic.
"""

from __future__ import annotations

import streamlit as st


def relationship_label(state):
    if state["trust"] <= 5 or (state["anger"] > 80 and state["stress"] > 75):
        return "hostile"
    if state["trust"] > 75:
        return "open"
    if state["trust"] < 25:
        return "guarded"
    return "uncertain"


def relationship_status(state, conversation_over):
    """Concise relationship read — no narrative 'almost gone' when interaction is over."""
    if conversation_over:
        return "Done"
    if state["anger"] > 78 and state["trust"] < 30:
        return "Tense"
    if state["trust"] < 20 and state["anger"] > 45:
        return "Closed off"
    if state["trust"] < 28:
        return "Guarded"
    if state["confusion"] > 70 or state["fear"] > 72:
        return "Uncomfortable"
    if state["stress"] > 74 and state["trust"] < 45:
        return "Uncomfortable"
    if state["trust"] > 70 and state["happiness"] > 52 and state["anger"] < 48:
        return "Open"
    if state["interest"] > 64 and state["trust"] >= 30 and state["anger"] < 58:
        return "Curious"
    if state["anger"] > 58 or state["stress"] > 64:
        return "Tense"
    if state["stress"] > 56 or state["happiness"] < 32:
        return "Guarded"
    return "Guarded"


def outcome_summary(state, name):
    score = state["trust"] + state["happiness"] + state["interest"] + state["confidence"]
    score -= state["anger"] + state["stress"] + state["fear"] + state["confusion"]
    if score > 110:
        verdict = "Strong positive outcome"
        advice = f"{name} feels comfortable, engaged, and relatively trusting. Your approach is working."
    elif score > 40:
        verdict = "Mixed but promising"
        advice = f"{name} is still open, but the interaction needs more care and consistency."
    elif score > -20:
        verdict = "Shaky interaction"
        advice = f"{name} is not fully lost, but trust and clarity need repair."
    else:
        verdict = "Poor outcome"
        advice = f"{name} feels guarded or overwhelmed. A reset in tone and approach would help."
    return verdict, advice


def fill_name_tokens(text):
    return str(text).replace("{name}", st.session_state.character_name)

