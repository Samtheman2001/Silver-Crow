"""
Streamlit rendering/presentation helpers.
"""

from __future__ import annotations

import random


def attribute_color(attr, delta):
    if delta == 0:
        return "#cbd5e1"
    good_when_up = attr in ["happiness", "trust", "confidence", "interest"]
    positive_good = (delta > 0 and good_when_up) or (delta < 0 and not good_when_up)
    return "#22c55e" if positive_good else "#ef4444"


def format_delta(delta):
    if delta == 0:
        return ""
    sign = "+" if delta > 0 else ""
    return f"{sign}{delta}"


def get_avatar(personality, state, murdered=False):
    if murdered:
        return random.choice(["😡", "🤬", "😤"])
    base = {
        "Confident": "😎",
        "Shy": "🙂",
        "Aggressive": "😤",
        "Empathetic": "😊",
        "Analytical": "🧐",
        "Impulsive": "🤪",
    }.get(personality, "🙂")
    if state["anger"] > 70:
        return "😠"
    if state["fear"] > 70:
        return "😬"
    if state["stress"] > 70:
        return "😵"
    if state["happiness"] > 70 and state["trust"] > 60:
        return "😊"
    if state["confusion"] > 65:
        return "🤨"
    return base


def app_css(st):
    """Inject CSS (Streamlit instance passed in)."""
    st.markdown(
        """
        <style>
        .stApp {
            background:
                linear-gradient(125deg, rgba(255,255,255,0.55) 0%, transparent 38%),
                linear-gradient(210deg, rgba(255,255,255,0.22) 0%, transparent 42%),
                radial-gradient(ellipse 90% 55% at 50% -8%, rgba(255,255,255,0.45), transparent 55%),
                radial-gradient(circle at top left, rgba(255,255,255,0.92), transparent 26%),
                radial-gradient(circle at top right, rgba(200,170,255,0.2), transparent 28%),
                radial-gradient(circle at bottom left, rgba(192,198,210,0.38), transparent 32%),
                radial-gradient(circle at bottom right, rgba(200,185,220,0.1), transparent 30%),
                linear-gradient(145deg, #f4f5f7 0%, #e8eaee 32%, #e4e6ec 55%, #f2f3f8 100%);
            color: #171a20;
        }
        header[data-testid="stHeader"] {background: rgba(255,255,255,0.12) !important; height: 0rem;}
        div[data-testid="stToolbar"] {top: 0.35rem; right: 0.5rem;}
        div[data-testid="stDecoration"] {display: none;}
        .block-container {padding-top: 1.45rem; padding-bottom: 0.4rem; max-width: 1680px;}
        .main-title {
            font-size: 2.0rem; font-weight: 1000; letter-spacing: 0.03em; margin-bottom: 0.15rem;
            background: linear-gradient(90deg, #7c7f87 0%, #eef1f5 20%, #bfc7d6 44%, #c8a2ff 72%, #6a6f7a 100%);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
            text-shadow: 0 1px 0 rgba(255,255,255,0.55);
        }
        .subtitle {color: #5a5468; font-size: 0.92rem; margin-bottom: 0.45rem;}
        .panel {padding: 0.1rem 0 0 0;}
        .center-panel {padding-top: 0.15rem;}
        .section-title {
            font-size: 0.88rem; font-weight: 1000; margin-bottom: 0.4rem; color: #2a2638;
            letter-spacing: 0.14em; text-transform: uppercase;
        }
        .section-title--spaced { margin-top: 0.65rem; }
        .hero-avatar {font-size: 3.5rem; line-height: 1; margin-bottom: 0.12rem; filter: drop-shadow(0 3px 10px rgba(0,0,0,0.11));}
        .hero-name {
            font-size: 1.78rem; font-weight: 1000; margin-bottom: 0.5rem; color: #141a24;
            letter-spacing: 0.02em;
        }
        .hero-response {
            font-size: 1.72rem; line-height: 1.34; font-weight: 850; color: #121820; min-height: 4.5rem; margin-bottom: 0.65rem;
            letter-spacing: 0.008em; text-rendering: optimizeLegibility;
        }
        .meta-line {color: #3d4656; font-size: 0.98rem; margin-top: 0.15rem; line-height: 1.4;}
        .meta-line--you { font-size: 0.95rem; color: #4a5568; margin-top: 0.35rem; margin-bottom: 0.1rem; }
        .meta-line--state { font-size: 0.9rem; color: #5c6575; margin-top: 0.25rem; }
        .meta-line--physical { font-size: 0.9rem; color: #5c6575; margin-top: 0.12rem; font-style: italic; }
        .meta-line--status { margin-bottom: 0.35rem; }
        .scenario-head {
            font-size: 0.78rem; font-weight: 1000; letter-spacing: 0.11em; text-transform: uppercase;
            color: #6b7280; margin-bottom: 0.45rem;
        }
        .tiny {font-size:0.84rem;color:#596579;}
        .summary-line {font-size:0.94rem;color:#2d3645;margin:0.16rem 0;}
        .gameover {
            border: 1px solid rgba(180,160,220,0.4); border-radius: 24px; padding: 2.5rem 1.5rem; text-align: center;
            background: linear-gradient(180deg, rgba(245,240,255,0.85), rgba(230,220,245,0.92));
            box-shadow: 0 0 40px rgba(180,160,220,0.15), 0 14px 34px rgba(35,44,62,0.08), inset 0 1px 0 rgba(255,255,255,0.9);
            margin-bottom: 0.8rem;
            position: relative;
        }
        .gameover-big {
            font-size: 3rem; font-weight: 1000; letter-spacing: 0.18em; margin-bottom: 0.5rem;
            color: #4a3f6b;
            text-shadow: 0 0 24px rgba(180,160,220,0.5), 0 0 48px rgba(150,130,200,0.25);
            font-family: system-ui, -apple-system, sans-serif;
        }
        .gameover-small {font-size: 0.95rem; color: #5a5168; opacity: 0.9; letter-spacing: 0.02em;}
        .follow-card {padding: 0 0 0.35rem 0; margin-bottom: 0.35rem;}
        .follow-label {color:#7b61c8; font-size:0.78rem; font-weight:800; text-transform:uppercase; letter-spacing:0.08em; margin-bottom:0.25rem;}
        .follow-question {font-size:1.05rem; font-weight:800; color:#212735; margin-bottom:0.5rem;}
        .stButton > button {
            width: 100%;
            background: linear-gradient(180deg, #52ff1b 0%, #24de5f 100%) !important;
            color: #09130a !important;
            border: 1px solid rgba(255,255,255,0.85) !important;
            border-radius: 14px !important;
            font-weight: 1000 !important;
            min-height: 2.5rem !important;
            box-shadow: 0 0 0 1px rgba(0,0,0,0.02), 0 10px 22px rgba(37, 211, 102, 0.18), inset 0 1px 0 rgba(255,255,255,0.55) !important;
        }
        .stButton > button:hover {filter: brightness(1.03); box-shadow: 0 14px 28px rgba(37,211,102,0.24), inset 0 1px 0 rgba(255,255,255,0.65) !important;}

        .recovery-buttons-marker { display: none; }

        /* Post-failure recovery: vivid purple / neon (distinct from green primaries) */
        div:has(.recovery-buttons-marker) + div .stButton > button,
        div:has(.gameover) + div + div .stButton > button {
            background: linear-gradient(175deg, #8b5cf6 0%, #6d28d9 38%, #4c1d95 100%) !important;
            color: #f5f3ff !important;
            border: 1px solid #c4b5fd !important;
            border-radius: 14px !important;
            box-shadow:
                0 0 22px rgba(139, 92, 246, 0.7),
                0 0 48px rgba(109, 40, 217, 0.4),
                0 8px 24px rgba(30, 20, 60, 0.25),
                inset 0 1px 0 rgba(255,255,255,0.38),
                inset 0 -1px 0 rgba(30, 20, 80, 0.25) !important;
            text-shadow: 0 0 14px rgba(196, 181, 253, 0.55) !important;
        }
        div:has(.recovery-buttons-marker) + div .stButton > button:hover,
        div:has(.gameover) + div + div .stButton > button:hover {
            filter: brightness(1.1) saturate(1.12) !important;
            box-shadow:
                0 0 32px rgba(167, 139, 250, 0.9),
                0 0 56px rgba(124, 58, 237, 0.5),
                inset 0 1px 0 rgba(255,255,255,0.5) !important;
        }
        label, .stSelectbox label, .stTextInput label {color: #1f2734 !important; font-weight: 800 !important; opacity: 1 !important;}
        .status-box {padding: 0; margin-bottom: 0.45rem;}
        .delta-chip {font-weight:900; font-size:0.9rem; margin-left:0.35rem;}
        .builder-title {font-size:1.4rem; font-weight:1000; color:#1b2330; margin-bottom:0.2rem;}
        .builder-sub {color:#586277; margin-bottom:0.6rem;}
        .stMarkdown p {margin-bottom: 0.3rem;}

        .relationship-pill {
            display: inline-block; font-weight: 900; font-size: 0.94em;
            padding: 0.1rem 0.55rem; border-radius: 999px;
            background: linear-gradient(180deg, rgba(255,255,255,0.65), rgba(232,230,242,0.75));
            border: 1px solid rgba(185,180,210,0.4);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.9);
        }
        .crow-brain-card {
            margin-top: 0.55rem;
            margin-bottom: 0.65rem;
            padding: 0.55rem 0.7rem;
            border-radius: 16px;
            background: linear-gradient(175deg, rgba(255,255,255,0.6), rgba(236,234,244,0.64));
            border: 1px solid rgba(200,195,220,0.30);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.86), 0 8px 20px rgba(19,24,36,0.05);
        }
        .crow-brain-title {
            font-size: 0.75rem; font-weight: 1000; letter-spacing: 0.12em;
            text-transform: uppercase; color: #5b5f72; margin-bottom: 0.28rem;
        }
        .crow-brain-line { font-size: 0.82rem; color: #2a3140; line-height: 1.35; margin-bottom: 0.18rem; }

        .character-sheet {
            margin-top: 0.85rem; padding: 0.65rem 0.72rem 0.62rem 0.72rem;
            border-radius: 16px;
            background: linear-gradient(175deg, rgba(255,255,255,0.62), rgba(236,234,244,0.66));
            border: 1px solid rgba(200,195,220,0.34);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.88), 0 8px 22px rgba(19,24,36,0.06);
        }
        .character-card-name {
            font-size: 1.08rem; font-weight: 1000; color: #141a24; letter-spacing: 0.02em;
            margin-bottom: 0.5rem; padding-bottom: 0.4rem;
            border-bottom: 1px solid rgba(170,175,195,0.38);
        }
        .character-sheet-line { font-size: 0.81rem; color: #2a3140; line-height: 1.42; margin-bottom: 0.1rem; }
        .cs-k { color: #6b7080; font-weight: 800; margin-right: 0.32rem; }

        /* chrome cards */
        div[data-testid="stVerticalBlock"] > div:has(> div > .section-title),
        div[data-testid="stVerticalBlock"] > div:has(> div > .builder-title),
        div[data-testid="stVerticalBlock"] > div:has(> div > .gameover) {
            background: linear-gradient(175deg, rgba(255,255,255,0.88), rgba(236,234,246,0.76));
            border: 1px solid rgba(200,195,220,0.32);
            box-shadow:
                0 16px 40px rgba(19, 24, 36, 0.09),
                inset 0 1px 0 rgba(255,255,255,0.95),
                inset 0 -1px 0 rgba(150,155,175,0.06);
            border-radius: 22px;
            padding: 0.9rem 1rem 1rem 1rem;
            backdrop-filter: blur(18px);
        }

        div[data-baseweb="select"] > div {
            background: linear-gradient(180deg, rgba(255,255,255,0.92), rgba(238,235,248,0.96)) !important;
            color: #17202c !important;
            border: 1px solid rgba(200,190,220,0.3) !important;
            border-radius: 14px !important;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.78), 0 6px 18px rgba(17,24,39,0.05);
        }
        div[data-baseweb="select"] svg {fill:#5b6475 !important;}

        .stTextInput input {
            background: linear-gradient(180deg, rgba(255,255,255,0.93), rgba(238,235,248,0.96)) !important;
            color: #17202c !important;
            border-radius: 14px !important;
            border: 1px solid rgba(200,190,220,0.28) !important;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.78), 0 6px 18px rgba(17,24,39,0.05);
        }

        .stat-row { margin-bottom: 0.78rem; }
        .stat-label-line {
            color: #1a2230; font-size: 0.96rem; margin-bottom: 0.36rem; line-height: 1.35;
        }
        .stat-label-line b { font-weight: 900; }
        .stat-value { font-weight: 1000; font-size: 1.05rem; }
        .stat-bar-track {
            width: 100%;
            max-width: 100%;
            background: linear-gradient(180deg, #e8eef8, #dce6f4);
            border-radius: 999px;
            height: 12px;
            overflow: hidden;
            box-sizing: border-box;
            box-shadow: inset 0 1px 2px rgba(15,23,42,0.06);
        }
        .stat-bar-fill {
            background: linear-gradient(90deg, #2563eb, #6366f1);
            height: 100%;
            min-height: 12px;
            width: 0%;
            border-radius: 999px;
        }

        [data-testid="stSidebar"] {
            background: linear-gradient(180deg, rgba(255,255,255,0.96), rgba(240,238,248,0.96));
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

